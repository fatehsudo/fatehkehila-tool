print ('V7x Tool v 1.5')

print ('Coded By V7x Team')

print ('WwW.Vairous7x.CoM')

print ('http://www.youtube.com/c/Vairous7x')

print ('Bye (*_^) ')
